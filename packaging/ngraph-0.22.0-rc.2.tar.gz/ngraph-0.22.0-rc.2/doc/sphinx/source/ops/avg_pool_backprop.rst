.. avg_pool_backprop.rst:

###############
AvgPoolBackprop
###############

.. code-block:: cpp

   AvgPoolBackprop // Average Pooling backprop operation.


Description
===========



C++ Interface
=============

.. doxygenclass:: ngraph::op::AvgPoolBackprop
   :project: ngraph
   :members:

Python Interface
================

