ngraph.exceptions
=================

.. automodule:: ngraph.exceptions

   
   
   


   
   
   


   
   

   .. rubric:: Exceptions

   .. autosummary::
     :nosignatures:
   
      NgraphError
      NgraphTypeError
      UserInputError
   
   