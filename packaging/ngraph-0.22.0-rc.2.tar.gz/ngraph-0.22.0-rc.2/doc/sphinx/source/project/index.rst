.. project/index:

#################
More about nGraph
#################

This section contains documentation about the project and how to contribute.


.. toctree::
   :maxdepth: 2

   about.rst
   contribution-guide.rst
   governance.rst
   doc-contributor-README.rst
