.. backend-support/executable-api/index.rst:


Executable
==========

The ``compile`` function on an ``Executable`` has more direct methods to 
actions such as ``validate``, ``call``, ``get_performance_data``, and so on. 


.. doxygenclass:: ngraph::runtime::Executable
   :project: ngraph
   :members: 

