.. backend-support/tensor-api/index.rst:


Tensor
======

.. doxygenclass:: ngraph::runtime::Tensor
   :project: ngraph
   :members:
